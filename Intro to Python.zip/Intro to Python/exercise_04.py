inputNum = int(input("Enter a number: "))
floats = []
for i in range(inputNum):
    inputFloat = float(input("Enter number " + str(i+1) +": "))
    floats.append(inputFloat)

print("List:", floats)

sum = 0
for number in floats:
    sum += number

average = sum / inputNum
print("Average:", average)