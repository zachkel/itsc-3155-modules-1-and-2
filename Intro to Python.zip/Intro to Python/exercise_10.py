inputString = input("Enter a string: ")
singleChar = list(inputString)
listList = []
for i in range(0, len(singleChar), 3):
    listList.append(singleChar[i:i+3])

print(listList)