numList = []
for i in range(1,11):
    inputNum = input("Enter number " + str(i) + ": ")
    inputNum = int(inputNum)
    numList.append(inputNum)

numOnce = []
for number in numList:
    if numList.count(number) == 1:
        numOnce.append(number)

print("Original List:", numList)
print("Nums that appear once:", numOnce)