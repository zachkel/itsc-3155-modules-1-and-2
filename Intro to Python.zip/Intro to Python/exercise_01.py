print("Enter a grade from 0 to 100: ")
grade = int(input())

if grade>=90 and grade<=100:
    print("Your grade is A")
elif grade>=80 and grade<90:
    print("Your grade is B")
elif grade>=70 and grade<80:
    print("Your grade is C")
elif grade>=60 and grade<70:
    print("Your grade is D")
elif grade<60:
    print("Your grade is F")
else:
    print("Invalid Input!")