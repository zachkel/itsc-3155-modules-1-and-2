row = int(input("Enter a row num from 1 to 5: "))
col = int(input("Enter a col num from 1 to 5: "))

grid = []
for i in range(1,6):
    listRow = []
    for j in range(1,6):
        if i == row and j == col:
            listRow.append(1)
        else:
            listRow.append(0)
    grid.append(listRow)

for row in grid:
    print(row)