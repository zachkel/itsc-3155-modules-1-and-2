print("Enter a string: ")
stringOne = input()
print("Enter another string: ")
stringTwo = input()

if stringOne.endswith(stringTwo):
    print("True")
elif stringTwo.endswith(stringOne):
    print("True")
else:
    print("False")