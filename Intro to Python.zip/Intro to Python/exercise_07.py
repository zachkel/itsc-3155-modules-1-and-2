allNums = []
while True:
    inputNum = input("Enter a number or QUIT to quit: ")
    if inputNum == "QUIT":
        break
    else:
        inputNum = int(inputNum)
        allNums.append(inputNum)

evenNums = []
for number in allNums:
    if number % 2 == 0:
        evenNums.append(number)

print("All Nums:", allNums)
print("Even Nums:", evenNums)