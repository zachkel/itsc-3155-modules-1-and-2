print("Enter an integer greater than 1: ")
inputNum = int(input())
for i in range(inputNum+1):
    cube = i*i*i
    print("The cube of", i, "is", cube)