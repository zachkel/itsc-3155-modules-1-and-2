listWords = []

for i in range(5):
    inputWord = input("Enter a word: ")
    listWords.append(inputWord)

oneString = " ".join(listWords)
print("Words:", listWords)
print("One String:", oneString)
