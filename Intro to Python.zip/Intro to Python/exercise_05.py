listOne=[]
listTwo=[]
listCommon=[]

for i in range(5):
    inputNum = int(input("Enter a number for the first list:"))
    listOne.append(inputNum)

for i in range(5):
    inputNum = int(input("Enter a number for the second list:"))
    listTwo.append(inputNum)

for integer in listOne:
    if integer in listTwo:
        listCommon.append(integer)

print("First List:", listOne)
print("Second List:", listTwo)
print("Common List:", listCommon)